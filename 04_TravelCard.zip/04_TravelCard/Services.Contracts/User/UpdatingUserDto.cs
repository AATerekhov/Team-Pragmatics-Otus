﻿namespace Services.Contracts.User
{
    /// <summary>
    /// ДТО редактирования юзера
    /// </summary>
    public class UpdatingUserDto
    {
        /// <summary>
        /// Логин
        /// </summary>
        public string Login { get; set; }
    }
}
