﻿namespace Infrastructure.Repositories.Implementations
{
    public class Class1
    {

    }
}
