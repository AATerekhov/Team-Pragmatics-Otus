﻿using AutoMapper;
using Services.Abstractions;
using Services.Repositories.Abstractions;
using Services.Contracts.User;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Domain.Entities;

namespace Services.Implementations
{
    /// <summary>
    /// Сервис работы с уроками.
    /// </summary>
    public class UserService : IUserService
    {
        private readonly IMapper _mapper;
        private readonly IUserRepository _UserRepository;

        public UserService (IMapper mapper, IUserRepository UserRepository)
        {
            _mapper = mapper;
            _UserRepository = UserRepository;
        }

        public Task<int> CreateAsync(CreatingUserDto creatingLessonDto)
        {
            throw new NotImplementedException();
        }

        public Task DeleteAsync(int id)
        {
            throw new NotImplementedException();
        }
        /// <summary>
        /// Получить юзера.
        /// </summary>
        /// <param name="id"> Идентификатор. </param>
        /// <param name="cancellationToken"> Токен отмены </param>
        /// <returns> ДТО юзера. </returns>
        public async Task<UserDto> GetByIdAsync(int id, CancellationToken cancellationToken)
        {
            var user = await _UserRepository.GetAsync(id, cancellationToken);
            return _mapper.Map<User, UserDto>(user);
        }

        public Task UpdateAsync(int id, UpdatingUserDto updatingLessonDto)
        {
            throw new NotImplementedException();
        }
    }
}
