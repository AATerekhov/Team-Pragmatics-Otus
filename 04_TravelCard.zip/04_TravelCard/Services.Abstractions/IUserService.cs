﻿using Services.Contracts;
using Services.Contracts.User;

namespace Services.Abstractions
{
    /// <summary>
    /// Интерфейс сервиса работы с юзерами.
    /// </summary>
    public interface IUserService
    {
        /// <summary>
        /// Получить урок. 
        /// </summary>
        /// <param name="id"> Идентификатор. </param>
        /// <param name="cancellationToken"> Токен отмены </param>
        /// <returns> ДТО юзера. </returns>
        Task<UserDto> GetByIdAsync(int id, CancellationToken cancellationToken);

        /// <summary>
        /// Создать юзера.
        /// </summary>
        /// <param name="CreatingUserDto"> ДТО создания юзера. </param>
        /// <returns> Идентификатор. </returns>
        Task<int> CreateAsync(CreatingUserDto creatingLessonDto);

        /// <summary>
        /// Изменить юзера.
        /// </summary>
        /// <param name="id"> Идентификатор. </param>
        /// <param name="UpdatingUserDto"> ДТО редактирования юзера. </param>
        Task UpdateAsync(int id, UpdatingUserDto updatingLessonDto);

        /// <summary>
        /// Удалить юзера.
        /// </summary>
        /// <param name="id"> Идентификатор. </param>
        Task DeleteAsync(int id);

        /// <summary>
        /// Получить список юзеров.
        /// </summary>
        /// <param name="page"> Номер страницы. </param>
        /// <param name="pageSize"> Объем страницы. </param>
        /// <returns> Страница юзеров. </returns>
        //Task<ICollection<UserDto>> GetPagedAsync(int page, int pageSize);
    }
}
