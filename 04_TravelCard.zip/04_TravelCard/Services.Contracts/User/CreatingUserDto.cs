﻿namespace Services.Contracts.User
{
    /// <summary>
    /// ДТО создания юзера
    /// </summary>
    public class CreatingUserDto
    {
        /// <summary>
        /// Идентификатор юзера.
        /// </summary>
        public int UserId { get; set; }

        /// <summary>
        /// Логин
        /// </summary>
        public string Login { get; set; }
    }
}
